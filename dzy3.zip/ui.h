#pragma once


void UIdisplay();
void LoginUI();
int UI();